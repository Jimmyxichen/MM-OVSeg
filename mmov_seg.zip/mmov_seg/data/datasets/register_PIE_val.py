import os
from detectron2.data import DatasetCatalog, MetadataCatalog
from detectron2.data.datasets import load_sem_seg

DLRSD_CATEGORIES = [
    {"color": [128, 128, 128], "id": 1, "name": "backbroad"},
    {"color": [235, 51, 36], "id": 2, "name": "city"},
    {"color": [255, 253, 85], "id": 3, "name": "road"},
    {"color": [66, 236, 245], "id": 4, "name": "water"},
    {"color": [56, 168, 0], "id": 5, "name": "forest"},
    {"color": [168, 112, 0], "id": 6, "name": "farmland"},
]

def _get_DLRSD_meta():
    stuff_ids = [k["id"] for k in DLRSD_CATEGORIES]
    stuff_dataset_id_to_contiguous_id = {k: i for i, k in enumerate(stuff_ids)}
    stuff_classes = [k["name"] for k in DLRSD_CATEGORIES]
    stuff_colors = [k["color"] for k in DLRSD_CATEGORIES]

    ret = {
        "stuff_dataset_id_to_contiguous_id": stuff_dataset_id_to_contiguous_id,
        "stuff_classes": stuff_classes,
        "stuff_colors": stuff_colors,
    }
    return ret

def register_DLRSD(root):
    meta = _get_DLRSD_meta()
    for name, image_dirname, sem_seg_dirname in [
        ("valrgb", "PIE_RGBSAR/val/rgb", "PIE_RGBSAR/val/D2masks6"),
        ("val", "PIE_RGBSAR/val/rgb_clouds", "PIE_RGBSAR/val/D2masks6"),
    ]:
        image_dir = os.path.join(root, image_dirname)
        gt_dir = os.path.join(root, sem_seg_dirname)
        name = f"PIE_{name}_sem_seg"
        DatasetCatalog.register(
            name, lambda x=image_dir, y=gt_dir: load_sem_seg(y, x, gt_ext="png", image_ext="png")
        )
        MetadataCatalog.get(name).set(
            image_root=image_dir,
            sem_seg_root=gt_dir,
            evaluator_type="sem_seg",
            ignore_label=255,
            **meta,
        )

root = "/yourpath/MM-OVSeg/Dataset"  # 替换为DLRSD数据集的根目录
register_DLRSD(root)

