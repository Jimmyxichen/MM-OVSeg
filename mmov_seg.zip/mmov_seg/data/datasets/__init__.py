# Copyright (c) Facebook, Inc. and its affiliates.
from . import (
    register_DDSK_train,
    register_DDSK_val,
    register_DDCH_val,
    register_PIE_train,
    register_PIE_val,
    register_DFC25thick_train,
    register_DFC25thick_val,
    register_DFC25thin_train,
    register_DFC25thin_val,
)
